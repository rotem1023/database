/*--------------------------------------------------Q1--------------------------------------------------*/
/*
Full text query: What is the decade with the highest percentage of movie titles having the word love out of all movies, in the US?
*/

select
       floor(release_year/10)*10 as decade,
       round(count(if(match(title, country) against ('the'), 1, NULL)) * 100 / count(id), 2) as percentage
from movie
where country = 'USA'
group by decade
having count(id) > 500
order by percentage desc
;

/*--------------------------------------------------Q2--------------------------------------------------*/
/*
Which actor, who is also a writer, has the largest amount of films where he both acted and wrote the script?
 */

select a.first_name         as actor_first_name,
       a.last_name          as actor_last_name,
       w.first_name         as writer_first_name,
       w.last_name          as writer_last_name,
       count(distinct m.id) as number_of_collaborations
from writer as w,
     actor as a,
     movie as m,
     actor_movie as am,
     writer_movie as wm
where w.id = wm.writer_id
  and a.id = am.actor_id
  and m.id = wm.movie_id
  and m.id = am.movie_id
  and a.first_name = w.first_name
  and a.last_name = w.last_name
group by w.id, a.id, w.first_name, w.last_name, a.first_name, a.last_name
order by number_of_collaborations desc
;

/*--------------------------------------------------Q3--------------------------------------------------*/
/*
Which movie has the largest amount of different languages in it?
 */

select m.title, count(lm.language_id) as num_of_languages
from movie as m,
     language_movie as lm
where lm.movie_id = m.id
group by m.id, m.title
order by num_of_languages desc
;

/*--------------------------------------------------Q4--------------------------------------------------*/
/*
which genre has the highest percentage of R rated films?
 */


select genre_ratings.genre_name,
       round(genre_ratings.number_of_R_rated_movies * 100 / genre_ratings.number_of_all_rated_movies, 2) as percentage_of_R_rated_movies
from (
         select g.genre_name,
                sum(IF(movie.rated = 'R', 1, 0)) as number_of_R_rated_movies,
                count(movie.rated)         as number_of_all_rated_movies
         from movie
                  join genre_movie gm on movie.id = gm.movie_id
                  join genre g on gm.genre_id = g.id
         group by g.id, g.genre_name
         order by number_of_R_rated_movies desc
     ) as genre_ratings
order by percentage_of_R_rated_movies desc
;

/*--------------------------------------------------Q5--------------------------------------------------*/
/*
which country has the shortest movies on average? (only for countries with more than 500 movies)
 */

select
       country,
       avg(runtime) average_runtime
from movie
where country in (
    select country
    from movie
    group by country
    having count(distinct movie.id) > 500
    )
group by country
;

/*--------------------------------------------------Q6--------------------------------------------------*/
/*
Who is the director with the highest rated movie according to imdb (that has more than 50k votes)
 */

select
       d.first_name,
       d.last_name,
       movie.title,
       movie.imdb_rating
from movie,
     director as d
where movie.imdb_votes > 50000
  and d.id = movie.director_id
  and movie.imdb_rating >= all (
    select m.imdb_rating
    from movie as m
    where m.imdb_votes > 50000);

/*--------------------------------------------------Q7--------------------------------------------------*/
/*
In which year the average budget of all movies was the highest?
*/

select m.release_year,
       round(avg(m.budget), 0) as yearly_movies_budget
from movie as m
group by m.release_year
order by yearly_movies_budget desc
;

/*--------------------------------------------------Q8--------------------------------------------------*/
/*
Who was the busiest actor in the year 2005?
 */

select actor.first_name,
       actor.last_name,
       movie.release_year,
       count(distinct movie.id) as number_of_films
from movie
         join actor_movie am on movie.id = am.movie_id
         join actor on am.actor_id = actor.id
where movie.release_year = 2005
group by actor.id, movie.release_year
order by number_of_films desc
;
