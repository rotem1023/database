import mysql.connector

LOCAL_HOST = 'localhost'
USER = 'DbMysql07'
PASSWORD = 'DbMysql07'
DATABASE = 'DbMysql07'

def get_con():
    con = mysql.connector.connect(host=LOCAL_HOST,
                                  port= 3305,
                                  user=USER,
                                  password=PASSWORD,
                                  database=DATABASE)
    return con


DB_CONNECTION = get_con()

################### Queries ####################

def get_q1(string, country):
    return f"""
        select
           floor(release_year/10)*10 as decade,
           round(count(if(match(title) against ('{string}'), 1, NULL)) * 100 / count(id), 2) as percentage
    from movie
    where country = '{country}'
    group by decade
    having count(id) > 500
    order by percentage desc
    """


def get_q2():
    return f"""
        select a.first_name     as actor_first_name,
           a.last_name          as actor_last_name,
           w.first_name         as writer_first_name,
           w.last_name          as writer_last_name,
           count(distinct m.id) as number_of_collaborations
    from writer as w,
         actor as a,
         movie as m,
         actor_movie as am,
         writer_movie as wm
    where w.id = wm.writer_id
      and a.id = am.actor_id
      and m.id = wm.movie_id
      and m.id = am.movie_id
      and a.first_name = w.first_name
      and a.last_name = w.last_name
    group by w.id, a.id, w.first_name, w.last_name, a.first_name, a.last_name
    order by number_of_collaborations desc
    """


def get_q3():
    return f"""
    select m.title, count(lm.language_id) as num_of_languages
    from movie as m,
         language_movie as lm
    where lm.movie_id = m.id
    group by m.id, m.title
    order by num_of_languages desc
    """

def get_q4(rating):
    return f"""
    select genre_ratings.genre_name,
           round(genre_ratings.number_of_given_rating_movies * 100 / genre_ratings.number_of_all_rated_movies, 2) as percentage_of_given_rating_movies
    from (
             select g.genre_name,
                    sum(IF(movie.rated = '{rating}', 1, 0)) as number_of_given_rating_movies,
                    count(movie.rated)         as number_of_all_rated_movies
             from movie
                      join genre_movie gm on movie.id = gm.movie_id
                      join genre g on gm.genre_id = g.id
             group by g.id, g.genre_name
             order by number_of_given_rating_movies desc
         ) as genre_ratings
    order by percentage_of_given_rating_movies desc
    """

def get_q5(min_num):
    return f"""
    select
           country,
           avg(runtime) average_runtime
    from movie
    where country in (
        select country
        from movie
        group by country
        having count(distinct movie.id) > {min_num}
        )
    group by country
    """

def get_q6(min_num):
    return f"""
    select
           d.first_name,
           d.last_name,
           movie.title,
           movie.imdb_rating
    from movie,
         director as d
    where movie.imdb_votes > {min_num}
      and d.id = movie.director_id
      and movie.imdb_rating >= all (
        select m.imdb_rating
        from movie as m
        where m.imdb_votes > {min_num});
    """


def get_q7():
    return f"""
    select m.release_year,
           round(avg(m.budget), 0) as yearly_movies_budget
    from movie as m
    group by m.release_year
    order by yearly_movies_budget desc
    """

def get_q8(year):
    return f"""
    select actor.first_name,
           actor.last_name,
           movie.release_year,
           count(distinct movie.id) as number_of_films
    from movie
             join actor_movie am on movie.id = am.movie_id
             join actor on am.actor_id = actor.id
    where movie.release_year = {year}
    group by actor.id, movie.release_year
    order by number_of_films desc
    """

################### Connection to DB ####################

def get_query(q):
    try:
        cur= DB_CONNECTION.cursor()
        cur.execute(q)
        rows= cur.fetchall()
        for row in rows:
            print(row)
        cur.close()
        print("-------------------------------------End of query-------------------------------------")
    except:
        print("problem with query")
    return


if __name__ == '__main__':
    # Q1
    get_query(get_q1('the', 'USA'))
    # Q2
    get_query(get_q2())
    # Q3
    get_query(get_q3())
    # Q4
    rating = 'R'
    get_query(get_q4(rating))
    # Q5
    min_number_of_votes = 500
    get_query(get_q5(min_number_of_votes))
    # Q6
    min_number_of_votes = 50000
    get_query(get_q6(min_number_of_votes))
    # Q7
    get_query(get_q7())
    # Q8
    year = 2005
    get_query(get_q8(year))



