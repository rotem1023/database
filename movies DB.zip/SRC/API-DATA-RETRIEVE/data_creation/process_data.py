import json
import csv
import pandas as pd
import collections

def read_data(filename):
    with open(filename, 'r') as f:
        res = json.load(f)
    return res

def id_to_int(imdb_id):
    return int(imdb_id[2:])


##################################################################################################
# Creating unique ids for actors, writers, directors and genres:
##################################################################################################


def create_ids_for_all_actors(seq_list):
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)

        mapping_filename = "./data_creation/temp_data/actors_map.json"
        with open(mapping_filename, 'r') as f:
            actors_map = json.load(f)

        next_available_id = len(actors_map) + 1
        for key, value in data.items():
            if value:
                actors_list = value.get('actors').split(',')
                for actor in actors_list:
                    actor = actor.strip()
                    # Check if actor not already in mapping
                    if not actors_map.get(actor):
                        actors_map[actor] = next_available_id
                        next_available_id += 1

        with open(mapping_filename, 'w') as f:
            f.write(json.dumps(actors_map))


def create_ids_for_all_writers(seq_list):
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)

        mapping_filename = "./data_creation/temp_data/writers_map.json"
        with open(mapping_filename, 'r') as f:
            writers_map = json.load(f)

        next_available_id = len(writers_map) + 1
        for key, value in data.items():
            if value:
                writers_list = value.get('writer').split(',')
                for writer in writers_list:
                    writer = writer.strip()
                    # Check if writer not already in mapping
                    if not writers_map.get(writer):
                        writers_map[writer] = next_available_id
                        next_available_id += 1

        with open(mapping_filename, 'w') as f:
            f.write(json.dumps(writers_map))


def create_ids_for_all_genres(seq_list):
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)

        mapping_filename = "./data_creation/temp_data/genres_map.json"
        with open(mapping_filename, 'r') as f:
            genres_map = json.load(f)

        next_available_id = len(genres_map) + 1
        for key, value in data.items():
            if value:
                genres_list = value.get('genre').split(',')
                for genre in genres_list:
                    genre = genre.strip()
                    # Check if genre not already in mapping
                    if not genres_map.get(genre):
                        genres_map[genre] = next_available_id
                        next_available_id += 1

        with open(mapping_filename, 'w') as f:
            f.write(json.dumps(genres_map))


def create_ids_for_all_languages(seq_list):
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)

        mapping_filename = "./data_creation/temp_data/languages_map.json"
        with open(mapping_filename, 'r') as f:
            languages_map = json.load(f)

        next_available_id = len(languages_map) + 1
        for key, value in data.items():
            if value:
                languages_list = value.get('language').split(',')
                for language in languages_list:
                    language = language.strip()
                    # Check if language not already in mapping
                    if not languages_map.get(language):
                        languages_map[language] = next_available_id
                        next_available_id += 1

        with open(mapping_filename, 'w') as f:
            f.write(json.dumps(languages_map))


def create_ids_for_all_directors(seq_list):
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)

        mapping_filename = "./data_creation/temp_data/directors_map.json"
        with open(mapping_filename, 'r') as f:
            directors_map = json.load(f)

        next_available_id = len(directors_map) + 1
        for key, value in data.items():
            if value:
                directors_list = value.get('director').split(',')
                # Take only first director if there are more than 1
                director = directors_list[0]
                # Check if director not already in mapping
                if not directors_map.get(director):
                    directors_map[director] = next_available_id
                    next_available_id += 1

        with open(mapping_filename, 'w') as f:
            f.write(json.dumps(directors_map))


##################################################################################################
# Creating tables:
##################################################################################################


def create_actors_table(seq_list):
    # Read mapping of actors to dict
    with open("./data_creation/temp_data/actors_map.json", 'r') as f_map:
        actors_map = json.load(f_map)

    ### Write data of actors
    actors_filename = "./tables/actor_table.csv"
    actors_header = ['id', 'first_name', 'last_name']
    # write only header
    with open(actors_filename, 'w', encoding='UTF8') as actors_f:
        csv_writer_a = csv.writer(actors_f)
        csv_writer_a.writerow(actors_header)

    # write data
    with open(actors_filename, 'a', encoding='UTF8') as actors_f:
        csv_writer_a = csv.writer(actors_f)
        for name_st, actor_id in actors_map.items():
            names = name_st.split(' ', 1)
            first_name = names[0]
            last_name = ""
            if len(names) > 1:
                last_name = " ".join(names[1:])
            row_a = [actor_id, first_name, last_name]
            csv_writer_a.writerow(row_a)


    ### write data of actor-movie
    actor_movie_filename = "./tables/actor_movie_table.csv"
    actor_movie_header = ['actor_id', 'movie_id']
    # write only header
    with open(actor_movie_filename, 'w', encoding='UTF8') as actor_movie_f:
        csv_writer_am = csv.writer(actor_movie_f)
        csv_writer_am.writerow(actor_movie_header)

    # write data
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)
        with open(actor_movie_filename, 'a', encoding='UTF8') as actor_movie_f:
            csv_writer_am = csv.writer(actor_movie_f)
            for key, value in data.items():
                if value:
                    actors = value.get('actors').split(',')
                    for actor in actors:
                        actor = actor.strip()
                        actor_id = actors_map.get(actor)
                        row_am = [actor_id, id_to_int(key)]
                        csv_writer_am.writerow(row_am)


def create_writers_table(seq_list):
    # Read mapping of actors to dict
    with open("./data_creation/temp_data/writers_map.json", 'r') as f_map:
        writers_map = json.load(f_map)

    ### Write data of writers
    writers_filename = "./tables/writer_table.csv"
    writers_header = ['id', 'first_name', 'last_name']
    # write only header
    with open(writers_filename, 'w', encoding='UTF8') as writers_f:
        csv_writer_a = csv.writer(writers_f)
        csv_writer_a.writerow(writers_header)

    # write data
    with open(writers_filename, 'a', encoding='UTF8') as writers_f:
        csv_writer_a = csv.writer(writers_f)
        for name_st, writer_id in writers_map.items():
            names = name_st.split(' ', 1)
            first_name = names[0]
            last_name = ""
            if len(names) > 1:
                last_name = " ".join(names[1:])
            row_a = [writer_id, first_name, last_name]
            csv_writer_a.writerow(row_a)

    ### write data of writer-movie
    writer_movie_filename = "./tables/writer_movie_table.csv"
    writer_movie_header = ['writer_id', 'movie_id']
    # write only header
    with open(writer_movie_filename, 'w', encoding='UTF8') as writer_movie_f:
        csv_writer_wm = csv.writer(writer_movie_f)
        csv_writer_wm.writerow(writer_movie_header)

    # write data
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)
        with open(writer_movie_filename, 'a', encoding='UTF8') as writer_movie_f:
            csv_writer_wm = csv.writer(writer_movie_f)
            for key, value in data.items():
                if value:
                    writers = value.get('writer').split(',')
                    for writer in writers:
                        writer = writer.strip()
                        writer_id = writers_map.get(writer)
                        row_wm = [writer_id, id_to_int(key)]
                        csv_writer_wm.writerow(row_wm)



def create_directors_table():
    # Read mapping of directors to dict
    with open("./data_creation/temp_data/directors_map.json", 'r') as f_map:
        directors_map = json.load(f_map)

    ### Write data of directors
    directors_filename = "./tables/director_table.csv"
    directors_header = ['id', 'first_name', 'last_name']
    # write only header
    with open(directors_filename, 'w', encoding='UTF8') as directors_f:
        csv_writer_d = csv.writer(directors_f)
        csv_writer_d.writerow(directors_header)

    # write data
    with open(directors_filename, 'a', encoding='UTF8') as directors_f:
        csv_writer_d = csv.writer(directors_f)
        for name_st, director_id in directors_map.items():
            names = name_st.split(' ', 1)
            first_name = names[0]
            last_name = ""
            if len(names) > 1:
                last_name = " ".join(names[1:])
            row_d = [director_id, first_name, last_name]
            csv_writer_d.writerow(row_d)


def create_genres_table(seq_list):
    # Read mapping of actors to dict
    with open("./data_creation/temp_data/genres_map.json", 'r') as f_map:
        genres_map = json.load(f_map)

    ### Write data of genres
    genres_filename = "./tables/genre_table.csv"
    genres_header = ['id', 'name']
    # write only header
    with open(genres_filename, 'w', encoding='UTF8') as genres_f:
        csv_writer_g = csv.writer(genres_f)
        csv_writer_g.writerow(genres_header)

    # write data
    with open(genres_filename, 'a', encoding='UTF8') as genres_f:
        csv_writer_g = csv.writer(genres_f)
        for name_st, genre_id in genres_map.items():
            # TODO: handle null name (N/A)
            row_a = [genre_id, name_st]
            csv_writer_g.writerow(row_a)

    ### write data of genre-movie
    genre_movie_filename = "./tables/genre_movie_table.csv"
    genre_movie_header = ['genre_id', 'movie_id']
    # write only header
    with open(genre_movie_filename, 'w', encoding='UTF8') as genre_movie_f:
        csv_writer_gm = csv.writer(genre_movie_f)
        csv_writer_gm.writerow(genre_movie_header)

    # write data
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)
        with open(genre_movie_filename, 'a', encoding='UTF8') as genre_movie_f:
            csv_writer_gm = csv.writer(genre_movie_f)
            for key, value in data.items():
                if value:
                    genres = value.get('genre').split(',')
                    for genre in genres:
                        genre = genre.strip()
                        genre_id = genres_map.get(genre)
                        row_gm = [genre_id, id_to_int(key)]
                        csv_writer_gm.writerow(row_gm)


def create_languages_table(seq_list):
    # Read mapping of languages to dict
    with open("./data_creation/temp_data/languages_map.json", 'r') as f_map:
        languages_map = json.load(f_map)

    ### Write data of languages
    languages_filename = "./tables/language_table.csv"
    languages_header = ['id', 'name']
    # write only header
    with open(languages_filename, 'w', encoding='UTF8') as languages_f:
        csv_writer_l = csv.writer(languages_f)
        csv_writer_l.writerow(languages_header)

    # write data
    with open(languages_filename, 'a', encoding='UTF8') as languages_f:
        csv_writer_l = csv.writer(languages_f)
        for name_st, language_id in languages_map.items():
            # TODO: handle null name (N/A)
            row_a = [language_id, name_st]
            csv_writer_l.writerow(row_a)

    ### write data of language-movie
    language_movie_filename = "./tables/language_movie_table.csv"
    language_movie_header = ['language_id', 'movie_id']
    # write only header
    with open(language_movie_filename, 'w', encoding='UTF8') as language_movie_f:
        csv_writer_lm = csv.writer(language_movie_f)
        csv_writer_lm.writerow(language_movie_header)

    # write data
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)
        with open(language_movie_filename, 'a', encoding='UTF8') as language_movie_f:
            csv_writer_lm = csv.writer(language_movie_f)
            for key, value in data.items():
                if value:
                    languages = value.get('language').split(',')
                    for language in languages:
                        language = language.strip()
                        language_id = languages_map.get(language)
                        row_lm = [language_id, id_to_int(key)]
                        csv_writer_lm.writerow(row_lm)


def create_movies_table(seq_list):
    dest_filename = f"/Users/batel/Documents/Private/TAU/tau-databases/hw3/tables/movie_table.csv"
    header = [
        'id',
        'title',
        'director_id',
        'release_year',
        'release_date',
        'rating',
        'runtime_minutes',
        'country',
        'imdb_rating',
        'imdb_votes'
    ]

    # Write only header
    with open(dest_filename, 'w', encoding='UTF8') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow(header)

    # Read directors mapping
    with open("./data_creation/temp_data/directors_map.json", 'r') as f_map:
        directors_map = json.load(f_map)

    # Write data
    for seq in seq_list:
        results_filename = f"./data_creation/api_results/kaggle_omdb_movies_results_{seq}.json"
        data = read_data(results_filename)
        with open(dest_filename, 'a', encoding='UTF8') as f:
            csv_writer = csv.writer(f)
            for key, value in data.items():
                if value:
                    title = value.get('title')
                    director_id = directors_map.get(value.get('director').split(',', 1)[0])
                    release_year = value.get('year')
                    release_date = value.get('released')
                    rating = value.get('rated')

                    # Fix country data
                    if rating == 'Unrated' or rating == 'Not Rated' or rating == 'UNRATED' or rating == 'NOT RATED':
                        rating = None

                    if rating == 'TV-G' or rating == 'TV-Y7' or rating == 'TV-Y7-FV' or rating == 'TV-Y':
                        rating = 'G'

                    if rating == 'TV-PG' or rating == 'GP':
                        rating = 'PG'

                    if rating == 'TV-13' or rating == 'TV-14':
                        rating = 'PG-13'

                    if rating == 'M/PG' or rating == 'Not Rated':
                        rating = 'R'

                    if rating == 'TV-MA' or rating == 'X' or rating == 'M' or rating == 'E':
                        rating = 'NC-17'

                    if rating == 'Passed' or rating == 'Open':
                        rating = 'Approved'


                    runtime_minutes = value.get('runtime').split(" ", 1)[0]
                    country = value.get('country').split(",", 1)[0]

                    # Fix country data
                    if country == 'United States':
                        country = 'USA'

                    if country == 'United Kingdom':
                        country = 'UK'

                    imdb_rating = value.get('imdb_rating')

                    # # Fix rt rating data
                    # if len(value.get('ratings')) > 1:
                    #     if '%' in value.get('ratings')[1].get('value'):
                    #         rotten_tomatoes_rating = value.get('ratings')[1].get('value').replace('%', '')
                    #     else:
                    #         rotten_tomatoes_rating = int(value.get('ratings')[1].get('value').split('/')[0])
                    # else:
                    #     rotten_tomatoes_rating = None

                    # Fix imdb_votes data
                    if value.get('imdb_votes') != 'N/A':
                        imdb_votes = int(value.get('imdb_votes').replace(',', ''))
                    else:
                        imdb_votes = None
                    row = [id_to_int(key), title, director_id, release_year, release_date, rating, runtime_minutes,
                           country, imdb_rating, imdb_votes]
                    csv_writer.writerow(row)


def clean_duplicates(table_path):
    data = pd.read_csv(table_path)
    print(f"Length of {table_path} before cleaning is {len(data)}")
    # dups = [item for item, count in collections.Counter(data['id']).items() if count > 1]
    data_without_dups = data.drop_duplicates()
    print(f"Length of {table_path} after cleaning is {len(data_without_dups)}")
    print(f"cleaned {len(data) - len(data_without_dups)} duplicates")
    data_without_dups.to_csv(table_path, index=False)


if __name__ == '__main__':
    ### TODO: the following needs to run on all data before building the table themselves
    cur_seq = [i for i in range(28)]
    # create_ids_for_all_actors(cur_seq)
    # create_ids_for_all_writers(cur_seq)
    # create_ids_for_all_genres(cur_seq)
    # create_ids_for_all_directors(cur_seq)
    # create_ids_for_all_languages(cur_seq)

    ### Building the tables
    create_movies_table(cur_seq)
    # create_directors_table()
    # create_actors_table(cur_seq)
    # create_writers_table(cur_seq)
    # create_genres_table(cur_seq)
    # create_languages_table(cur_seq)
    clean_duplicates('./tables/movie_table.csv')
    # clean_duplicates('./tables/actor_movie_table.csv')
    # clean_duplicates('./tables/genre_movie_table.csv')
    # clean_duplicates('./tables/language_movie_table.csv')
    # clean_duplicates('./tables/writer_movie_table.csv')
