import csv
import pandas as pd

def create_reduced_table():
    csv_file = open("/Users/batel/Documents/Private/TAU/year_3/מערכות בסיסי נתונים/שיעורי בית/hw3/movies_metadata.csv", 'r')
    output_file = open("./data_creation/temp_data/additional_csv_table.csv", 'w')
    input_reader = csv.reader(csv_file)
    writer = csv.writer(output_file)
    for row in input_reader:
        imdb_id = row[6]
        budget = row[2]
        original_language = row[7]
        try:
            revenue = row[15]
        except:
            revenue = None

        if budget == 0:
            budget = None

        if revenue == 0:
            revenue = None

        if imdb_id == 'imdb_id':
            new_row = ['id', 'budget', 'revenue', 'original_language']
            writer.writerow(new_row)
        elif imdb_id != 0 and imdb_id != '0' and imdb_id[:2] == 'tt':
            new_row = [int(imdb_id[2:]), budget, revenue, original_language]
            writer.writerow(new_row)

    csv_file.close()
    output_file.close()

def join_with_movie_table():
    movie_table_path = './tables/movie_table.csv'
    new_table_path = './data_creation/temp_data/additional_csv_table.csv'
    l = pd.read_csv(movie_table_path)
    r = pd.read_csv(new_table_path)
    r = r.drop_duplicates()
    print(len(l))
    print(len(r))
    merged = l.merge(r, on='id', how='left')
    print(len(merged))
    merged.to_csv("./tables/combined_movie_table.csv", index=False)


if __name__ == '__main__':
    # create_reduced_table()
    join_with_movie_table()