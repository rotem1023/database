import omdb
import json

# Our configurations
# Batel's 1st key is 23781ff3 (tau mail)
# Batel's 2nd key is 4f5cae4a (personal mail)
# Rotem's 1st key is 6d8663b4
# Rotem's 2nd key is e42d8b19
# last update:
OMDB_API_KEY = "e42d8b19"

# API configuration
omdb.set_default('apikey', OMDB_API_KEY)
omdb.set_default('tomatoes', True) # If we want the data from rotten tomatoes. Don't see why not
omdb.set_default('timeout', 10) # set a global timeout of 10 seconds for all HTTP requests

def read_ids(filename):
    # Return list of ids from file
    with open(filename, 'r') as ids_file:
        ids = ids_file.read().split('\n')
    return ids


def get_data(seq):
    entity = "movies"
    origin_filename = f"./raw_data/kaggle_imdb_{entity}_ids_{seq}.txt"
    destination_filename = f"./api_results/kaggle_omdb_{entity}_results_{seq}.json"
    imdb_movies_ids = read_ids(origin_filename)
    failed_ids =[]

    # Get all movies data from API, by movie ID
    movies_res = {}
    non_empty_results = 0
    for imdb_id in imdb_movies_ids:
        try:
            res = omdb.imdbid(imdb_id)
            non_empty_results += 1
        except:
            res = {}
            print(f"failed querying {imdb_id}")
            failed_ids.append(imdb_id)
        print(f"got {non_empty_results} results until now")
        movies_res[imdb_id] = res

    # check how many results we got
    print(f"Number of ids sent to API: {len(imdb_movies_ids)}")
    print(f"Number of non empty results sent from API: {non_empty_results}")

    # store movies data to file
    with open(destination_filename, 'w') as output_file:
        output_file.write(json.dumps(movies_res))

    # store failed ids to file
    with open(f"./logs/omdb_{entity}_failed_ids_{seq}.txt", 'w') as output_file:
        for imdb_id in failed_ids:
            output_file.write("%s\n" % imdb_id)


if __name__ == '__main__':
    # TODO: CHANGE THIS NUMBER EVERY TIME YOU RUN THE SCRIPT
    # sequence_number = 28
    get_data(sequence_number)