import csv
MAX_SIZE_PER_FILE = 1000
MAX_IDS_TO_READ = 30000

#####
# This file only needs to be run once, to read 20k IDs from the IMDB tsv file, available online
#####


def create_raw_data_form_title_basics():
    tsv_file = open("/Users/batel/Documents/Private/TAU/year_3/מערכות בסיסי נתונים/שיעורי בית/hw3/title.basics.tsv")
    read_tsv = csv.reader(tsv_file, delimiter="\t")
    imdb_ids = []
    for row in read_tsv:
        imdb_ids.append(row[0])

    # Take only last 20k ids from database, we don't need more
    imdb_ids.reverse()
    last_20k_ids = imdb_ids[:MAX_IDS_TO_READ]

    # Write every 1k IDs to separate file
    for i in range(20):
        ids_to_write = last_20k_ids[i * MAX_SIZE_PER_FILE:(i + 1) * MAX_SIZE_PER_FILE]
        print(len(ids_to_write))
        with open(f"./raw_data/imdb_movies_ids_{i}.txt", 'w') as f:
            for imdb_id in ids_to_write:
                f.write("%s\n" % imdb_id)

def create_raw_data_from_kaggle_csv():
    tsv_file = open("/Users/batel/Documents/Private/TAU/year_3/מערכות בסיסי נתונים/שיעורי בית/hw3/movies_metadata.csv")
    read_tsv = csv.reader(tsv_file)
    imdb_ids = []
    for row in read_tsv:
        if row[6] != 'imdb_id':
            imdb_ids.append(row[6])

    # Take 30k ids from database
    last_30k_ids = imdb_ids[:MAX_IDS_TO_READ]

    # Write every 1k IDs to separate file
    for i in range(30):
        ids_to_write = last_30k_ids[i * MAX_SIZE_PER_FILE:(i + 1) * MAX_SIZE_PER_FILE]
        print(len(ids_to_write))
        with open(f"./raw_data/kaggle_imdb_movies_ids_{i}.txt", 'w') as f:
            for imdb_id in ids_to_write:
                f.write("%s\n" % imdb_id)


if __name__ == '__main__':
    create_raw_data_from_kaggle_csv()