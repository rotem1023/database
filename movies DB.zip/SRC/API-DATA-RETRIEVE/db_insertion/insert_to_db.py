import pandas as pd
import  mysql.connector
import math
from mysql.connector import errorcode

#actor_path= "C:\\Users\\rotem\\OneDrive\\programing\\db1\\tau-databases\\hw3\\tables\\actors_table.csv"
actor_path="../tables/actor_table.csv"
movie_path= "../tables/combined_movie_table.csv"
language_path= "../tables/language_table.csv"
genre_path= "../tables/genre_table.csv"
director_path= "../tables/director_table.csv"
writer_path= "../tables/writer_table.csv"
writer_movie_path= "../tables/writer_movie_table.csv"
actor_movie_path= "../tables/actor_movie_table.csv"
language_movie_path= "../tables/language_movie_table.csv"
genre_movie_path= "../tables/genre_movie_table.csv"

###################
### hel functions
###################

#nova.cs.tau.ac.il
#mysqlsrv1.cs.tau.ac.il

def get_con():
    con = mysql.connector.connect(host='localhost', port= 3305, user='DbMysql07', password='DbMysql07',database='DbMysql07')
    return con

def modify_date(date):
    #### change the date from table format to sql format
    lst= date.split()
    d= {'Jan':1, 'Feb':2, 'Mar':3, 'Apr':4, 'May':5, 'Jun':6, 'Jul':7, 'Aug':8, 'Sep':9, 'Oct':10, 'Nov':11, 'Dec':12}
    output= str(lst[2])+'-'+str(d[lst[1]]) +'-'+str(lst[0])
    return output

def change_nan(val):
    ### change nan to None
    if (isinstance(val, float)):
        if val>0:
            return val
        return None
    return val


###################
### END- hel functions
###################

#################
#### insert DB functions
#################

def insert_role(role_type, filePath):
    data= pd.read_csv(filePath)
    con =get_con()
    cursor= con.cursor()
    fail_data= pd.DataFrame({'id':[], 'first_name':[], 'last_name':[]})
    if role_type=="actor":
        query= """INSERT INTO actor (id, first_name, last_name) values (%s,%s,%s)"""
    elif role_type=="writer":
        query = """INSERT INTO writer (id, first_name, last_name) values (%s,%s,%s)"""
    elif role_type=="director":
        query = """INSERT INTO director (id, first_name, last_name) values (%s,%s,%s)"""
    for i in range(len(data)):
        row= data.iloc[i]
        insert_val= (int(row['id']), row['first_name'], row['last_name'])
        if (isinstance(insert_val[2], float)):
            insert_val = (int(row['id']), row['first_name'], None)
        try:
            cursor.execute(query,insert_val)
            con.commit()
            print(f"line {i} was added to {role_type} table")
        except:
            tmp_dic= {'id':insert_val[0], 'first_name':insert_val[1], 'last_name':insert_val[2]}
            fail_data=fail_data.append(tmp_dic, ignore_index=True)
            print(f"line {i} was not added to {role_type} table")
    if (len(fail_data)>0):
        fail_data.to_csv(f"./fail_insertion_{role_type}.csv", index=False)
    cursor.close()
    print(f"finish insert for table {role_type}")
    return


def insert_lan_or_genre(filePath, table_type):
    data = pd.read_csv(filePath)
    con = get_con()
    cursor = con.cursor()
    fail_data = pd.DataFrame({'id': [], 'name': []})
    if table_type == "language":
        query = """INSERT INTO language (id, language_name) values (%s,%s)"""
    elif table_type == "genre":
        query = """INSERT INTO genre (id, genre_name) values (%s,%s)"""
    for i in range(len(data)):
        row = data.iloc[i]
        insert_val = (int(row['id']), row['name'])
        try:
            cursor.execute(query, insert_val)
            con.commit()
            print(f"line {i} was added to {table_type} table")
        except:
            tmp_dic = {'id': insert_val[0], 'name': insert_val[1]}
            fail_data = fail_data.append(tmp_dic, ignore_index=True)
            print(f"line {i} was not added to {table_type} table")
    if (len(fail_data) > 0):
        fail_data.to_csv(f"./fail_insertion_{table_type}.csv", index=False)
    cursor.close()
    print(f"finish insert for table {table_type}")
    return

def insert_connect_table(filePath, table_type):
    '''
    function that update movie table language_movie tale or  genre_movie table or actor_movie table or  writer_movie table
    :param table_type: (string) language_movie\genre_movie\actor_movie\writer_movie
    :return:
    '''
    data = pd.read_csv(filePath)
    con = get_con()
    cursor = con.cursor()
    fail_data = pd.DataFrame({'movie_id': [], 'other_id': []})
    if table_type == "language_movie":
        query = """INSERT INTO language_movie (movie_id, language_id) values (%s,%s)"""
    elif table_type == "genre_movie":
        query = """INSERT INTO genre_movie (movie_id, genre_id) values (%s,%s)"""
    elif table_type == "actor_movie":
        query = """INSERT INTO actor_movie (movie_id, actor_id) values (%s,%s)"""
    elif table_type == "writer_movie":
        query = """INSERT INTO writer_movie (movie_id, writer_id) values (%s,%s)"""
    for i in range(len(data)):
        row = data.iloc[i]
        try:
            ### getting values to insert
            if table_type == "language_movie":
                insert_val = (int(row['movie_id']), int(row['language_id']))
            elif table_type == "genre_movie":
                insert_val = (int(row['movie_id']), int(row['genre_id']))
            elif table_type == "actor_movie":
                insert_val = (int(row['movie_id']), int(row['actor_id']))
            elif table_type == "writer_movie":
                insert_val = (int(row['movie_id']), int(row['writer_id']))
        except:
            continue
        try:
            ### insert on row for the table
            cursor.execute(query, insert_val)
            con.commit()
            print(f"line {i} was added to {table_type} table")
        except:
            ### saving the data we could not insert into DB in exexl File
            tmp_dic = {'movie_id': insert_val[0], 'other_id': insert_val[1]}
            fail_data = fail_data.append(tmp_dic, ignore_index=True)
            print(f"line {i} was not added to {table_type} table")
    if (len(fail_data) > 0):
        fail_data.to_csv(f"./fail_insertion_{table_type}.csv", index=False)
    cursor.close()
    print(f"finish insert for table {table_type}")
    return



def insert_movie(filePath):
    '''
    function that update movie table
    :param filePath: (string) movies table path
    :return: (None)
    '''
    data= pd.read_csv(filePath)
    con =get_con()
    cursor= con.cursor()
    query= """INSERT INTO movie (id, title, release_year, rated, release_date, runtime, country, imdb_rating, director_id, imdb_votes, budget, revenue) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
    fail_data = pd.DataFrame({'id': [], 'title': [], 'release_year': [],'rated': [], 'release_date': [], 'runtime': [],'country': [], 'imdb_rating': [], 'director_id': [],'revenue': [], 'imdb_votes': [], 'budget': []})
    for i in range(len(data)):
        row= data.iloc[i]
        try:
            ### insert one row for the table
            budget= int(row['budget'])
            if budget==0:
                budget=None
            revenue = int(row['revenue'])
            if revenue == 0:
                revenue = None
            insert_val = (int(row['id']), row['title'], int(row['release_year']), change_nan(row['rating']),
                          modify_date(row['release_date']),
                          int(row['runtime_minutes']), row['country'], float(row['imdb_rating']),
                          int(row['director_id']), int(row['imdb_votes']), budget, revenue)
            cursor.execute(query,insert_val)
            con.commit()
            print(f"line {i} was added to movie table")
        except:
            ### saving the data we could not insert into DB in exexl File
            try:
                tmp_dic= {'id': insert_val[0], 'title': insert_val[1], 'release_year': insert_val[2],'rated': insert_val[3], 'release_date': insert_val[4], 'runtime': insert_val[5],'country': insert_val[6], 'imdb_rating': insert_val[7], 'director_id': insert_val[8],'revenue': insert_val[11], 'imdb_votes': insert_val[9], 'budget': insert_val[10]}
            except:
                continue
            fail_data=fail_data.append(tmp_dic, ignore_index=True)
            print(f"line {i} was not added to movie table")
    if (len(fail_data)>0):
        fail_data.to_csv(f"./fail_insertion_movie.csv", index=False)
    cursor.close()
    print(f"finish insert for table movie")
    return

#################
#### END- insert DB functions
#################



if __name__ == '__main__':
    insert_role("director", director_path)
    insert_lan_or_genre(language_path,'language')
    insert_role("actor", actor_path)
    insert_role("writer", writer_path)
    insert_movie(movie_path)
    insert_connect_table(actor_movie_path, 'actor_movie')
    insert_connect_table(writer_movie_path, 'writer_movie')
    insert_connect_table(language_movie_path, 'language_movie')
    insert_connect_table(genre_movie_path, 'genre_movie')


