create table DbMysql07.director(
	id int not null primary key,
    first_name varchar(20) not null,
    last_name varchar(20)
);

create table DbMysql07.movie(
	id int not null primary key,
    title varchar(100) not null,
    release_year int,
    rated varchar(10),
    release_date date,
    runtime int,
    country varchar(30),
	imdb_rating float,
    director_id int,
	rotten_tomatoes_rating float,
    imdb_votes int,
	budget float,
    foreign key (director_id)
    references DbMysql07.director(id)
);

create table DbMysql07.actor(
	id int not null primary key,
    first_name varchar(20) not null,
    last_name varchar(20)
);

create table DbMysql07.writer(
	id int not null primary key,
    first_name varchar(20) not null,
    last_name varchar(20)
);

create table DbMysql07.genre(
	id int not null primary key,
    genre_name varchar(20) not null 
);


create table DbMysql07.actor_movie(
	movie_id int not null,
    actor_id int not null,
	foreign key (movie_id)
    references DbMysql07.movie(id),
	foreign key (actor_id)
    references DbMysql07.actor(id),
    primary key (movie_id, actor_id)
);

create table DbMysql07.writer_movie(
	movie_id int not null,
    writer_id int not null,
	foreign key (movie_id)
    references DbMysql07.movie(id),
	foreign key (writer_id)
    references DbMysql07.writer(id),
    primary key (movie_id, writer_id)
);

create table DbMysql07.genre_movie(
	movie_id int not null,
    genre_id int not null,
	foreign key (movie_id)
    references DbMysql07.movie(id),
	foreign key (genre_id)
    references DbMysql07.genre(id),
    primary key (movie_id, genre_id)
);

create table DbMysql07.language(
	id int not null primary key,
    language_name varchar(15) not null
);

create table DbMysql07.language_movie(
	movie_id int not null,
    language_id int not null,
	foreign key (movie_id)
    references DbMysql07.movie(id),
	foreign key (language_id)
    references DbMysql07.language(id),
    primary key (movie_id, language_id)
);


ALTER TABLE DbMysql07.actor 
modify COLUMN last_name varchar(80);

ALTER TABLE DbMysql07.director
modify COLUMN last_name varchar(80);

ALTER TABLE DbMysql07.writer 
modify COLUMN last_name varchar(80);


CREATE INDEX movie_release_year_index
ON movie (release_year);

CREATE INDEX movie_director_id_index
ON movie (director_id);


CREATE INDEX language_movie_movie_id_index
ON language_movie (movie_id);


CREATE INDEX actor_movie_movie_id_index
ON actor_movie (movie_id);

CREATE INDEX writer_movie_movie_id_index
ON writer_movie (movie_id);

CREATE INDEX genre_movie_movie_id_index
ON genre_movie (movie_id);

CREATE INDEX movie_imdb_votes_index
ON movie (imdb_votes);

alter table movie
drop column rotten_tomatoes_rating;

alter table movie
add revenue int;

ALTER TABLE movie  
ADD FULLTEXT(title);

CREATE INDEX movie_country
ON movie (country);

CREATE INDEX actor_first_name
ON actor (first_name);












